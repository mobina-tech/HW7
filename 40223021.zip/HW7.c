#include<stdio.h>       // Mobina Teromideh   40223021
#include<string.h>
#include<ctype.h>
int main()
{
    int n;
    int num;// it is strlen sentence1
    int j=0;
    int k=0;
    char temp;
    int i;

    printf("Enter numbers of words:");
    scanf("%d",&n);
    char language1 [n][60]={};
    char language2 [n][60]={};

    
    for(i=0;i<n;i++)
    {
        printf("Enter words:\n");
        scanf("%s %s",&language1[i],&language2[i]);
    }
    
    
    char sentence1[60]={};
    char sentence[60]={};
    char a[60][60]={};
     
    printf("Enter a sentence which made from language1:\n");
    getchar();
    for(i=0;i<60;i++)
    {
        scanf("%c",&sentence1[i]);
        if(sentence1[i]=='\n')//be enter residim
        {
            sentence1[i]='\0';//null gharar mide
            break;
        }
    }
    
    num=strlen(sentence1);
    
    if(toupper(language1[0][0])==language1[0][0])//mige if capital bood
    {
        for(i=0;i<num;i++)
        {
            sentence[i]=toupper(sentence1[i]);//output ham capital
        }
    }
            
    if(tolower(language1[0][0])==language1[0][0])//if small 
    {
        for(i=0;i<num;i++)
        {
            sentence[i]=tolower(sentence1[i]);//out put is small
        }
    }
                
    for(i=0;i<num;i++)
    {
        if(sentence[i]!=' ')//be space ke miresim kalame tamom mishe
        {
            temp=sentence[i];
            a[j][k]=temp;
            k=k+1;
        }
        else if(sentence[i]==' ') 
        {
            j=j+1;
            k=0;
        }
        
    }
    for(j=0;j<n;j++)
    {
        for(i=0;i<n;i++)
        {
            if(strcmp(a[j],language1[i]));//if meghdar gheir 0 shavad kar mikone
             //bedon dastor
             else if(strlen(language1[i])>strlen(language2[i]))//avali az dovomi bozorgtare
             {
                strcpy(a[j],language2[i]);
             }
             
        }
    }
    for(i=0;i<n;i++)
    {
        printf("%s ",a[i]);
    }
    
return 0;
}